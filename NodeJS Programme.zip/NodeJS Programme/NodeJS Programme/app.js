var express = require('express');
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
var app = express();
var urlencodedParser = bodyParser.urlencoded({ extended: false });
app.set('view engine', 'ejs');
app.use('/assets', express.static('assets'));


mongoose.connect("mongodb://admin:test123@174.129.131.232/Clients", {useNewUrlParser: true, useUnifiedTopology: true});

var db = mongoose.connection;
db.on('error', console.error.bind(console, 'ERROR, Failed to Connect to database.'));
db.once('open', function () {
  console.log("Database Conection succesful.");
})




///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////


///Customer Info Schema


var clientInfoSchema = new mongoose.Schema({
  F_Name : String,
  L_Name : String,
  Username : String,
  Password : String,
  User_Account_Number : 0,
  Client_Address : String,
  Gas_Required : String,
  Electric_Required : String,
  Status : String,
  Balance : "number",
  Card_Details : "number",
  Name_On_Card : String,
  Card_Type : String,
  Cvv : "number",
  Contact : String
});

var customers = mongoose.model('customers', clientInfoSchema);

var testCustomer = customers({
  F_Name : "Tim",
  L_Name : "Clancy",
  Username : "tim1",
  Password : "111",
  User_Account_Number : Math.random() * (100000 - 999999) + 999999,
  Client_Address : "201 Astley Street, Tyldesley, Greater Manchester, UK",
  Gas_Required : "yes",
  Electric_Required : "no",
  Status : "active",
  Balance : 150,
  Card_Details : 4404220211019909,
  Name_On_Card : "Mr T A Clancy",
  Card_Type : "Visa",
  Cvv : 202,
  Contact : "text"}).save(function(err) {
    if (err) throw err;
    console.log("Test User Saved To Database");
});


///Admin Info Schema

var adminInfoSchema = new mongoose.Schema({
  F_Name : String,
  L_Name : String,
  Username : String,
  Password : String
});

var adminDatabase = mongoose.model('adminDatabase', adminInfoSchema);

var testAdmin = adminDatabase({
    F_Name : "Mobius",
    L_Name : "Roman",
    Username : "admin",
    Password : "111"}).save(function(err) {
      if (err) throw err;
      console.log("Test User Saved To Database");
});

///client Message Schema

var clientMessagesSchema = new mongoose.Schema({
  Sender: String,
  Message: String
})
var clientMessages = mongoose.model('clientMessages', clientMessagesSchema);


///Admin Message Schema

var adminMessagesSchema = new mongoose.Schema({
  Message: String
})

var adminMessages = mongoose.model('adminMessages', adminMessagesSchema);


///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

///Index Node

app.get("/index", function(req, res) {res.render("index")});
app.get("/", function(req, res) {res.render("index")});

app.post("/index", urlencodedParser, function(req, res){
  customers.findOne({Username: req.body.username, Password: req.body.password}, function(err, data) {
    if (err) throw err;
    else if(data == null){
      res.redirect("back")
    }
    else {
      res.redirect('clientPage/' + req.body.username)
    }
  })
})


///////////////////////////////////////////////////////////////////////////////
///Client Node/////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////


app.get("/clientPage/:id", function(req, res) {
 var params = req.params.id
 var message;

 adminMessages.find({}, function(err, data){
   if(err) throw err;
   else{
     message = data
   }
 })

 customers.findOne({Username: params}, function(err, data){
   if(err) throw err;
   else{
     console.log(data)
     res.render("clientPage", {
       f_Name : data.F_Name,
       l_Name : data.L_Name,
       username : data.Username,
       password : data.Password,
       user_Account_Number : data.User_Account_Number,
       address : data.Client_Address,
       gas : data.Gas,
       electric : data.Electric,
       status : data.Status,
       balance : data.Balance,
       card_Details : data.Card_Details,
       name_On_Card : data.Name_On_Card,
       card_Type : data.Card_Type,
       cvv : data.Cvv,
       contact : data.Contact,
       Messages : message
     })
   }
 })
});

app.post("/clientPage", urlencodedParser, function(req, res){

  console.log(req.body.username);



  customers.deleteMany({Username: req.body.username}, function(err, obj) {
    if (err) throw err;
    console.log("Old User Deleted")
  });


  var first = req.body.First
  var last = req.body.Last
  var username = req.body.username
  var password = req.body.password
  var account = req.body.Account
  var address = req.body.Address
  var gas = req.body.Gas
  var electric = req.body.Electric
  var details = req.body.Details
  var nameOnCard = req.body.nameOnCard
  var cardType = req.body.cardType
  var cvv = req.body.CVV
  var contact = req.body.Contact

  var clientInsert = customers({
    F_Name : first,
    L_Name : last,
    Username : username,
    Password : password,
    User_Account_Number : account,
    Client_Address : address,
    Gas : gas,
    Electric : electric,
    Status : "active",
    Balance : 0,
    Card_Details : details,
    Name_On_Card : nameOnCard,
    Card_Type : cardType,
    Cvv : cvv,
    Contact : contact}).save(function(err){
    if (err) throw err;
    console.log("Test User Saved To Database");
    res.redirect("clientPage/" + username)
  })
})

app.post("/clientMessage", urlencodedParser, function(req, res){
  console.log(req.body.Message);
  var sender = req.body.Sender
  var message = req.body.Message

  var clientMessageInsert = clientMessages({
    Sender: sender,
    Message: message}).save(function(err){
    if (err) throw err;
    console.log("Test User Saved To Database")
    res.redirect("back")
  })
})

//////////////////////////////////////////////////////////////////////////////
///Registry Node//////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
app.get("/register", function(req, res) {res.render("register")});
app.post("/register", urlencodedParser, function(req, res){

  var first = req.body.First
  var last = req.body.Last
  var username = req.body.Username
  var password = req.body.Password
  var account = Math.random() * (100000 - 999999) + 999999;
  var address = req.body.Address
  var gas = req.body.Gas
  var electric = req.body.Electric
  var details = req.body.Details
  var nameOnCard = req.body.nameOnCard
  var cardType = req.body.cardType
  var cvv = req.body.CVV
  var contact = req.body.Contact

  var clientInsert = customers({
    F_Name : first,
    L_Name : last,
    Username : username,
    Password : password,
    User_Account_Number : account,
    Client_Address : address,
    Gas : gas,
    Electric : electric,
    Status : "active",
    Balance : 0,
    Card_Details : details,
    Name_On_Card : nameOnCard,
    Card_Type : cardType,
    Cvv : cvv,
    Contact : contact}).save(function(err){
    if (err) throw err;
    console.log("Saved To Database");
    res.redirect("index")
  })
})

///////////////////////////////////////////////////////////////////////////////
///Admin Node//////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////


app.post("/admin", urlencodedParser, function(req, res){
  adminDatabase.findOne({Username: req.body.username, Password: req.body.password}, function(err, data1) {
    if (err) throw err;
    else if(data1 == null){
      res.redirect("back")
    }
    else {
      res.redirect('adminPage/' + req.body.username)
    }
  })
})


app.get("/adminPage/:id", function(req, res) {
 var params = req.params.id

 clientMessages.find({}, function(err, data){
   if(err) throw err;
   else{
     console.log(data);
     res.render("adminPage", {Messages: data})
   }
 })
});
app.post("/adminPage", urlencodedParser, function(req, res){

  var first = req.body.First
  var last = req.body.Last
  var username = req.body.username
  var password = req.body.password
  var account = req.body.Account
  var address = req.body.Address
  var gas = req.body.Gas
  var electric = req.body.Electric
  var details = req.body.Details
  var nameOnCard = req.body.nameOnCard
  var cardType = req.body.cardType
  var cvv = req.body.CVV
  var contact = req.body.Contact

  var clientInsert = customers({
    F_Name : first,
    L_Name : last,
    Username : username,
    Password : password,
    User_Account_Number : account,
    Client_Address : address,
    Gas : gas,
    Electric : electric,
    Status : "active",
    Balance : 0,
    Card_Details : details,
    Name_On_Card : nameOnCard,
    Card_Type : cardType,
    Cvv : cvv,
    Contact : contact}).save(function(err){
    if (err) throw err;
    console.log("Saved To Database");
    res.render("adminPage")
  })
})

app.post("/adminMessage", urlencodedParser, function(req, res){
  var message = req.body.Messages

  var adminMessageInsert = adminMessages({
    Message: req.body.Message}).save(function(err){
    if (err) throw err;
    console.log("Saved To Database");
    res.redirect("back")
  })
})

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////


app.listen(3000)
